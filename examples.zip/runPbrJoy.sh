#!/bin/bash
./pbrJoystick.py > /dev/null

